// CONNECTION STRING FOR ORACLE DB
module.exports = {
  1: {
    user: "bccs_view",
    password: "bccs_view21101",
    // connectionString: "103.177.225.252:1521/xe",
    connectionString: "202.21.38.94:1521/xe",
    poolMax: 5,
    poolMin: 5,
    poolIncrement: 0,
  },
  2: {
    user: "puri_cbs_view",
    password: "puri_cbs_view161101",
    // connectionString: "103.177.225.252:1521/xe",
    connectionString: "202.21.38.94:1521/xe",
    poolMax: 5,
    poolMin: 5,
    poolIncrement: 0,
  },
};
