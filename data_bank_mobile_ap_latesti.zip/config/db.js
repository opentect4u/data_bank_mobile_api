const mysql = require('mysql');

 const db = mysql.createPool({
     connectionLimit: 10,
     host: "localhost",
     user: "root",
    //  user: "databank",
     password: "",
    //  password: "Data#Bank@Syn!2023",
     database: "databank",
 });

 db.getConnection((err, connection) => {
     if(err) console.log(err);
    connection.release();
    return;
 });

 module.exports = db;